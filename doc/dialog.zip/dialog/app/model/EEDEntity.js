Ext.define('EED.model.EEDEntity', {
    extend: 'Ext.data.Model'
});