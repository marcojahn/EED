Ext.onReady(function () {

    //(app_start)

});