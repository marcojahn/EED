Ext.onReady(function () {

    Ext.data.Connection.timeout = 5000;
    Ext.Ajax.timeout = 5000;

    Ext.ns('EED.application');

    // app_01

});